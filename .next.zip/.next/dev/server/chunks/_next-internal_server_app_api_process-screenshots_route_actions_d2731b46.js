module.exports = [
"[project]/.next-internal/server/app/api/process-screenshots/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_process-screenshots_route_actions_d2731b46.js.map