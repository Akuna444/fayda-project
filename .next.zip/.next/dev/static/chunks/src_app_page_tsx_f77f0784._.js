(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_2bcc7035._.js",
  "static/chunks/src_9e247464._.js",
  "static/chunks/node_modules_next_c9713438._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_jsbarcode_bin_bd8da5d2._.js",
  "static/chunks/node_modules_html2canvas-pro_dist_html2canvas-pro_esm_b15a70c4.js",
  "static/chunks/node_modules_52a2c28e._.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_0d42d46a.js",
  "static/chunks/node_modules_jszip_lib_de8925ba._.js",
  "static/chunks/node_modules_6ccea9af._.js"
],
    source: "dynamic"
});
