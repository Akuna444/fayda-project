module.exports=[99206,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_add-points_route_actions_d8c08db3.js.map