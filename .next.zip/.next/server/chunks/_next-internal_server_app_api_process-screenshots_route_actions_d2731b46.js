module.exports=[38990,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_process-screenshots_route_actions_d2731b46.js.map