module.exports=[89956,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_add-points_page_actions_b3d43f73.js.map